S.T.A.L.K.E.R Cursor Pack (Version 2), Created by The_Pants_Mobile

Update:
I have made 4 new cursors to go along with the original.
"Wait" replaces the hourglass, "highlight" replaces the pointing hand,
"WorkingInBackground" replaces the arrow hourglass combo, and
"sText" replaces the Textbar thing ("sText" isn't that great
Which I'm disappoint about, so you may just want to use the normal 
black
one, its alright I wont be offended ;D)
I'm too lazy to update the Installation Instructions for the 4 new ones,
But you're smart (you downloaded this didn't you?), I'm sure you can figure it out.



To install:

1: Extract file to C:\WINDOWS\Cursors
2: Go to control panel, then click appearance and themes
3: Find "mouse pointers" and click on it.
4: Double click on the normal select.
5: Find the stalker cursor, highlight it and click open.
6: Click ok and enjoy your new cursor!

I am licensing this under the terms of "Creative Communism" - Use it as you seem fit. Spread it. Take what you want, add, remove, change and improve. Why not sign with you own name and claim authorship? One rule, however: Don't you ever try subjecting this material under the terms of copyright, intellectual property, or similar licenses of evil.